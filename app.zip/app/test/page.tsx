'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Trash2, ChevronDown, ChevronRight, Plus, Check, X, RotateCcw, LogIn, LogOut, User, Clock, CheckCircle2 } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

// Mock login function - in a real app, this would interact with a backend
const mockLogin = (username: string, password: string) => {
  if (username === 'admin' && password === 'admin') {
    return { role: 'admin', name: 'Admin User' }
  } else if (username === 'user' && password === 'user') {
    return { role: 'member', name: 'Regular User' }
  }
  return null
}

interface User {
  role: string
  name: string
}

interface Task {
  id: number
  text: string
  estimatedTime: number
  subtasks: Task[]
  status: 'in_progress' | 'pending_approval' | 'completed'
  assignedTo: string
}

const Login = ({ onLogin }: { onLogin: (user: User) => void }) => {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')

  const handleLogin = () => {
    const user = mockLogin(username, password)
    if (user) {
      onLogin(user)
    } else {
      alert('Invalid credentials')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-purple-400 via-pink-500 to-red-500">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">Login to Productivity App</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="username" className="text-sm font-medium text-gray-700">Username</label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="password" className="text-sm font-medium text-gray-700">Password</label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
              />
            </div>
            <Button onClick={handleLogin} className="w-full">
              <LogIn className="mr-2 h-4 w-4" /> Login
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

const MemberManagement = ({ members, onAddMember, onRemoveMember }: { members: string[], onAddMember: (member: string) => void, onRemoveMember: (member: string) => void }) => {
  const [newMember, setNewMember] = useState('')

  const handleAddMember = () => {
    if (newMember.trim()) {
      onAddMember(newMember.trim())
      setNewMember('')
    }
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-xl font-semibold">Team Member Management</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row mb-4">
          <Input
            value={newMember}
            onChange={(e) => setNewMember(e.target.value)}
            placeholder="Enter member name"
            className="mb-2 sm:mb-0 sm:mr-2"
          />
          <Button onClick={handleAddMember}>Add Member</Button>
        </div>
        <ul className="space-y-2">
          {members.map((member, index) => (
            <motion.li
              key={index}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex justify-between items-center p-2 bg-gray-100 rounded-md"
            >
              <span className="font-medium">{member}</span>
              <Button onClick={() => onRemoveMember(member)} variant="destructive" size="sm">
                <Trash2 size={16} />
              </Button>
            </motion.li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

const Task = ({ task, members, onUpdate, onDelete, onAddSubtask, currentUser }: { task: Task, members: string[], onUpdate: (task: Task) => void, onDelete: (id: number) => void, onAddSubtask: (id: number) => void, currentUser: User }) => {
  const [isExpanded, setIsExpanded] = useState(false)

  const handleTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdate({ ...task, estimatedTime: parseInt(e.target.value) || 0 })
  }

  const handleAssignMember = (memberId: string) => {
    onUpdate({ ...task, assignedTo: memberId })
  }

  const handleStatusChange = (newStatus: Task['status']) => {
    onUpdate({ ...task, status: newStatus })
  }

  const calculateTotalTime = (t: Task): number => {
    if (t.subtasks && t.subtasks.length > 0) {
      return t.subtasks.reduce((acc, subtask) => acc + calculateTotalTime(subtask), 0)
    }
    return t.estimatedTime
  }

  const totalTime = calculateTotalTime(task)

  const isAdmin = currentUser.role === 'admin'
  const isAssigned = task.assignedTo === currentUser.name
  const canEdit = isAdmin || isAssigned

  const getStatusColor = (status: Task['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 border-green-300'
      case 'pending_approval':
        return 'bg-yellow-100 border-yellow-300'
      default:
        return 'bg-blue-100 border-blue-300'
    }
  }

  const taskStyle = `${getStatusColor(task.status)} border rounded-lg p-4 transition-all duration-300 ease-in-out`

  const handleAddSubtask = () => {
    onAddSubtask(task.id)
    setIsExpanded(true)
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className={`mb-4 ${taskStyle}`}
    >
      <div className="flex flex-col space-y-4">
        <div className="flex items-center space-x-2">
          {task.subtasks?.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1"
            >
              {isExpanded ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
            </Button>
          )}
          <Input
            value={task.text}
            onChange={(e) => onUpdate({ ...task, text: e.target.value })}
            className="flex-grow"
            disabled={!canEdit || task.status === 'completed'}
          />
        </div>
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4 text-gray-500" />
            <Input
              type="number"
              value={task.estimatedTime}
              onChange={handleTimeChange}
              className="w-20"
              placeholder="Time (min)"
              disabled={!canEdit || (task.subtasks && task.subtasks.length > 0) || task.status === 'completed'}
            />
          </div>
          <div className="flex items-center space-x-2">
            <User className="h-4 w-4 text-gray-500" />
            <Select onValueChange={handleAssignMember} value={task.assignedTo} disabled={!isAdmin || task.status === 'completed'}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Assign" />
              </SelectTrigger>
              <SelectContent>
                {members.map((member, index) => (
                  <SelectItem key={index} value={member}>{member}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <span className="text-sm font-medium text-gray-600">Total: {totalTime} min</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {isAdmin && task.status !== 'completed' && (
            <Button onClick={() => handleStatusChange('completed')} size="sm" variant="outline">
              <CheckCircle2 className="mr-1 h-4 w-4" /> Mark Completed
            </Button>
          )}
          {!isAdmin && isAssigned && task.status !== 'completed' && (
            <>
              {task.status === 'in_progress' && (
                <Button onClick={() => handleStatusChange('pending_approval')} size="sm" variant="outline">
                  Request Approval
                </Button>
              )}
              {task.status === 'pending_approval' && (
                <Button onClick={() => handleStatusChange('in_progress')} size="sm" variant="outline">
                  <RotateCcw className="mr-1 h-4 w-4" /> Revert to In Progress
                </Button>
              )}
            </>
          )}
          {isAdmin && task.status === 'pending_approval' && (
            <>
              <Button onClick={() => handleStatusChange('completed')} size="sm" variant="outline">
                <Check className="mr-1 h-4 w-4" /> Approve
              </Button>
              <Button onClick={() => handleStatusChange('in_progress')} size="sm" variant="outline">
                <X className="mr-1 h-4 w-4" /> Reject
              </Button>
            </>
          )}
          {isAdmin && task.status !== 'completed' && (
            <Button onClick={handleAddSubtask} size="sm" variant="outline">
              <Plus className="mr-1 h-4 w-4" /> Add Subtask
            </Button>
          )}
          {isAdmin && (
            <Button onClick={() => onDelete(task.id)} variant="destructive" size="sm">
              <Trash2 className="mr-1 h-4 w-4" /> Delete
            </Button>
          )}
        </div>
      </div>
      <AnimatePresence>
        {isExpanded && task.subtasks && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-4 ml-4 space-y-4"
          >
            {task.subtasks.map(subtask => (
              <Task
                key={subtask.id}
                task={subtask}
                members={members}
                onUpdate={(updatedSubtask) => {
                  onUpdate({
                    ...task,
                    subtasks: task.subtasks.map(st => st.id === updatedSubtask.id ? updatedSubtask : st)
                  })
                }}
                onDelete={(subtaskId) => {
                  onUpdate({
                    ...task,
                    subtasks: task.subtasks.filter(st => st.id !== subtaskId)
                  })
                }}
                onAddSubtask={(subtaskId) => {
                  onUpdate({
                    ...task,
                    subtasks: task.subtasks.map(st => st.id === subtaskId ? {
                      ...st,
                      subtasks: [...(st.subtasks || []), { id: Date.now(), text: '', estimatedTime: 0, status: 'in_progress', assignedTo: currentUser.name, subtasks: [] }]
                    } : st)
                  })
                }}
                currentUser={currentUser}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

export default function ProductivityApp() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [members, setMembers] = useState<string[]>([])
  const [currentUser, setCurrentUser] = useState<User | null>(null)

  useEffect(() => {
    // Initialize members with the admin user and a regular user
    setMembers(['Admin User', 'Regular User'])
    
    // Initialize with some sample tasks
    setTasks([
      {
        id: 1,
        text: 'Design new landing page',
        estimatedTime: 120,
        subtasks: [],
        status: 'in_progress',
        assignedTo: 'Admin User'
      },
      {
        id: 2,
        text: 'Implement user authentication',
        estimatedTime: 180,
        subtasks: [],
        status: 'in_progress',
        assignedTo: 'Regular User'
      }
    ])
  }, [])

  const addTask = () => {
    setTasks([...tasks, { 
      id: Date.now(), 
      text: '', 
      estimatedTime: 0, 
      subtasks: [], 
      status: 'in_progress',
      assignedTo: currentUser!.name  // Assign the task to the current user by default
    }])
  }

  const updateTask = (updatedTask: Task) => {
    setTasks(tasks.map(task => task.id === updatedTask.id ? updatedTask : task))
  }

  const deleteTask = (taskId: number) => {
    setTasks(tasks.filter(task => task.id !== taskId))
  }

  const addSubtask = (taskId: number) => {
    setTasks(tasks.map(task => task.id === taskId ? {
      ...task,
      subtasks: [...(task.subtasks || []), { 
        id: Date.now(), 
        text: '', 
        estimatedTime: 0, 
        status: 'in_progress',
        assignedTo: currentUser!.name,  // Assign the subtask to the current user by default
        subtasks: []
      }]
    } : task))
  }

  const addMember = (newMember: string) => {
    setMembers([...members, newMember])
  }

  const removeMember = (memberToRemove: string) => {
    setMembers(members.filter(member => member !== memberToRemove))
  }

  const handleLogin = (user: User) => {
    setCurrentUser(user)
  }

  const handleLogout = () => {
    setCurrentUser(null)
  }

  const calculateTotalTime = (t: Task): number => {
    if (t.subtasks && t.subtasks.length > 0) {
      return t.subtasks.reduce((acc, subtask) => acc + calculateTotalTime(subtask), 0)
    }
    return t.estimatedTime
  }

  const totalEstimatedTime = tasks.reduce((acc, task) => acc + calculateTotalTime(task), 0)

  if (!currentUser) {
    return <Login onLogin={handleLogin} />
  }

  const filteredTasks = currentUser.role === 'admin' 
    ? tasks 
    : tasks.filter(task => 
        task.assignedTo === currentUser.name || 
        task.subtasks.some(subtask => subtask.assignedTo === currentUser.name)
      )

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 p-4 sm:p-6 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-4 sm:mb-0">Productivity App</h1>
          <div className="flex items-center space-x-4">
            <span className="text-gray-600">Welcome, {currentUser.name} ({currentUser.role})</span>
            <Button onClick={handleLogout} variant="outline">
              <LogOut className="mr-2 h-4 w-4" /> Logout
            </Button>
          </div>
        </div>
        
        {currentUser.role === 'admin' && (
          <MemberManagement
            members={members}
            onAddMember={addMember}
            onRemoveMember={removeMember}
          />
        )}
        
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl font-semibold">Task Management</CardTitle>
          </CardHeader>
          <CardContent>
            {currentUser.role === 'admin' && (
              <Button onClick={addTask} className="mb-6">
                <Plus className="mr-2 h-4 w-4" /> Add New Task
              </Button>
            )}
            <AnimatePresence>
              {filteredTasks.length > 0 ? (
                filteredTasks.map(task => (
                  <Task
                    key={task.id}
                    task={task}
                    members={members}
                    onUpdate={updateTask}
                    onDelete={deleteTask}
                    onAddSubtask={addSubtask}
                    currentUser={currentUser}
                  />
                ))
              ) : (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-center text-gray-500 my-8"
                >
                  No tasks assigned to you yet.
                </motion.p>
              )}
            </AnimatePresence>
            <div className="mt-6 text-right">
              <span className="text-lg font-semibold">Total Estimated Time: {totalEstimatedTime} minutes</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}